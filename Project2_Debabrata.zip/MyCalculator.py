from tkinter import *
inputs = ""  # Global input string

# Create a function for pressing the buttons
def press(key):
    global inputs
    inputs += str(key)
    display.set(inputs)

# Create a function with the name equal() for 'equal to' operation
def equal():
    global inputs
    try:
        result = str(eval(inputs))
        display.set(result)
        inputs = result
    except:
        display.set("error")
        inputs = ""

# clear() for clearing the display on demand
def clear():
    global inputs
    inputs = ""
    display.set("0.0")

if __name__ == "__main__":
    # Create the main window
    root = Tk()
    root.configure(bg="dark grey")
    root.title("Debu's Calculator")
    root.geometry("360x227")

    # Create the display for results to show
    display = StringVar()
    display.set("0.0")
    entry = Entry(root, textvariable=display, font=("Arial", 12), bd=6, fg='black', bg='dark gray', relief=RIDGE)
    entry.grid(columnspan=4, ipadx=66, pady=10)
    
    # Create the buttons
    btn7 = Button(root, text='7', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(7), height=2, width=10)
    btn7.grid(row=3, column=0)
    btn8 = Button(root, text='8', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(8), height=2, width=10)
    btn8.grid(row=3, column=1)
    btn9 = Button(root, text='9', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(9), height=2, width=10)
    btn9.grid(row=3, column=2)
    btn4 = Button(root, text='4', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(4), height=2, width=10)
    btn4.grid(row=4, column=0)
    btn5 = Button(root, text='5', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(5), height=2, width=10)
    btn5.grid(row=4, column=1)
    btn6 = Button(root, text='6', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(6), height=2, width=10)
    btn6.grid(row=4, column=2)
    btn1 = Button(root, text='1', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(1), height=2, width=10)
    btn1.grid(row=5, column=0)
    btn2 = Button(root, text='2', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(2), height=2, width=10)
    btn2.grid(row=5, column=1)
    btn3 = Button(root, text='3', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(3), height=2, width=10)
    btn3.grid(row=5, column=2)
    plus = Button(root, text='+', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press('+'), height=2, width=10)
    plus.grid(row=3, column=3)
    minus = Button(root, text='-', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press('-'), height=2, width=10)
    minus.grid(row=4, column=3)
    mult = Button(root, text='*', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press('*'), height=2, width=10)
    mult.grid(row=5, column=3)
    div = Button(root, text='/', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press('/'), height=2, width=10)
    div.grid(row=6, column=3)
    clr = Button(root, text='C', font=("Arial", 10), fg='black', bg='dark grey', command=clear, height=2, width=10)
    clr.grid(row=6, column=0)
    btn0 = Button(root, text='0', font=("Arial", 10), fg='black', bg='dark grey', command=lambda: press(0), height=2, width=10)
    btn0.grid(row=6, column=1)
    eq = Button(root, text='=', font=("Arial", 10), fg='black', bg='dark grey', command=equal, height=2, width=10)
    eq.grid(row=6, column=2)
    
    root.mainloop()